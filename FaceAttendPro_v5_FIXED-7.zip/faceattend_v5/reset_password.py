"""
FaceAttend Pro - emergency password reset (run on the computer where the app runs)

Usage (from the faceattend_v5 folder):
  python reset_password.py
        -> shows every admin / teacher / student login, then resets the 3 DEMO
           accounts to:  admin@demo.com/admin123  kumar@demo.com/teacher123
                         kavya@demo.com/student123
  python reset_password.py admin   admin@demo.com   MyNewPass1
  python reset_password.py teacher kumar@demo.com   MyNewPass1
  python reset_password.py student STU001           MyNewPass1     (email, ID or roll no)
  python reset_password.py list    -> only list accounts, change nothing
"""
import sys
import app as A

MODELS = {"admin": A.Admin, "teacher": A.Teacher, "student": A.Student}
DEMO = [("admin","admin@demo.com","admin123"),
        ("teacher","kumar@demo.com","teacher123"),
        ("student","kavya@demo.com","student123")]

def show():
    print("\nAccounts in the database:")
    for role, M in MODELS.items():
        rows = M.query.order_by(M.id).all()
        print(f"\n  {role.upper()} ({len(rows)})")
        for u in rows[:50]:
            extra = f"  roll {u.roll_no}" if role == "student" else ""
            print(f"    id={u.id:<10} email={u.email}{extra}")
        if len(rows) > 50: print(f"    ... and {len(rows)-50} more")

def reset(role, ident, pw):
    u = A.find_account(MODELS[role], ident)
    if not u:
        print(f"  ✗ No {role} found for '{ident}'"); return False
    u.set_password(pw); A.db.session.commit()
    print(f"  ✓ {role}: {u.email}  (id {u.id})  ->  password is now: {pw}")
    return True

with A.app.app_context():
    args = sys.argv[1:]
    if args[:1] == ["list"]:
        show()
    elif len(args) == 3 and args[0] in MODELS:
        if len(args[2]) < 6: sys.exit("Password must be at least 6 characters")
        reset(*args)
    elif not args:
        show(); print("\nResetting demo accounts:")
        for r in DEMO: reset(*r)
        print("\nIf a demo account is missing above, use the list to find your real email, then run:\n"
              "  python reset_password.py <admin|teacher|student> <email-or-id> <new-password>")
    else:
        print(__doc__)
